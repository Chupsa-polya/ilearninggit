cp -npr dir1/dir2
